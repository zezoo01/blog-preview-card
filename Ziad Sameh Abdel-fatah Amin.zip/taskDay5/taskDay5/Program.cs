﻿using System.Resources;
using System;
using System.Runtime.CompilerServices;
using static System.Reflection.Metadata.BlobBuilder;
using System.Diagnostics.Metrics;
using System.Diagnostics;
using System.Linq.Expressions;
using System.Threading.Channels;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Collections.Generic;
using System.Numerics;
using System.Reflection.PortableExecutable;
using System.Text.RegularExpressions;

namespace taskDay5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region PART 1
            #region Q1
            //try
            //{
            //    Console.Write("Enter the first integer: ");
            //    int num1 = int.Parse(Console.ReadLine());
            //    Console.Write("Enter the second integer: ");
            //    int num2 = int.Parse(Console.ReadLine());
            //    int result = num1 / num2;
            //    Console.WriteLine($"Result: {result}");
            //}
            //catch (DivideByZeroException)
            //{
            //    Console.WriteLine("Error: Division by zero is not allowed.");
            //}
            //catch (FormatException)
            //{
            //    Console.WriteLine("Error: Please enter valid integers.");
            //}
            //finally
            //{
            //    Console.WriteLine("Operation complete.");
            //}
            ////What is the purpose of the finally block?
            ////The finally block ensures that specific code runs regardless of whether an exception occurs or not.
            ////It is typically used for cleanup tasks or final actions,
            ////such as releasing resources or displaying a message like "Operation complete."
            #endregion
            #region Q2
            //TestDefensiveCode();
            ////int.TryParse() check the user input if the format of this input valid return true else return false 
            #endregion
            #region Q3
            //int? nullableInt = null;
            //int assignedValue = nullableInt ?? 100;
            //Console.WriteLine($"Assigned Value (using ??): {assignedValue}");
            //nullableInt = 50; 

            //if (nullableInt.HasValue)
            //{
            //    Console.WriteLine($"HasValue: true, Value: {nullableInt.Value}");
            //}
            //else
            //{
            //    Console.WriteLine("HasValue: false, Value cannot be accessed.");
            //}
            //nullableInt = null;

            //try
            //{
            //    Console.WriteLine($"Trying to access Value when null: {nullableInt.Value}");
            //}
            //catch (InvalidOperationException ex)
            //{
            //    Console.WriteLine($"Exception: {ex.Message}");
            //}

            ////What exception occurs when trying to access Value on a null Nullable<T>?
            ////Exception is InvalidOperationException with a message like "Nullable object must have a value."

            #endregion
            #region Q4
            //int[] numbers = new int[5] { 10, 20, 30, 40, 50 };

            //try
            //{
            //    Console.WriteLine($"Accessing out-of-bounds index: {numbers[10]}");
            //}
            //catch (IndexOutOfRangeException ex)
            //{
            //    Console.WriteLine("Error: Attempted to access an index outside the array bounds.");
            //    Console.WriteLine($"Exception Message: {ex.Message}");
            //}
            #endregion
            #region Q5
            //int[,] array = new int[3, 3];
            //Console.WriteLine("Enter values for a 3x3 array:");
            //for (int i = 0; i < array.GetLength(0); i++)
            //{
            //    for (int j = 0; j < array.GetLength(1); j++)
            //    {
            //        Console.Write($"Enter value for [{i}, {j}]: ");
            //        array[i, j] = int.Parse(Console.ReadLine());
            //    }
            //}
            //Console.WriteLine("\nSum of rows:");
            //for (int i = 0; i < array.GetLength(0); i++)
            //{
            //    int rowSum = 0;
            //    for (int j = 0; j < array.GetLength(1); j++)
            //    {
            //        rowSum += array[i, j];
            //    }
            //    Console.WriteLine($"Row {i}: {rowSum}");
            //}
            //Console.WriteLine("\nSum of columns:");
            //for (int j = 0; j < array.GetLength(1); j++)
            //{
            //    int colSum = 0;
            //    for (int i = 0; i < array.GetLength(0); i++)
            //    {
            //        colSum += array[i, j];
            //    }
            //    Console.WriteLine($"Column {j}: {colSum}");
            //}
            #endregion
            #region Q6
            //int[][] jaggedArray = new int[3][];
            //jaggedArray[0] = new int[2]; // Row 1 with 2 elements
            //jaggedArray[1] = new int[4]; // Row 2 with 4 elements
            //jaggedArray[2] = new int[3]; // Row 3 with 3 elements
            //for (int i = 0; i < jaggedArray.Length; i++)
            //{
            //    Console.WriteLine($"Enter {jaggedArray[i].Length} values for row {i + 1}:");
            //    for (int j = 0; j < jaggedArray[i].Length; j++)
            //    {
            //        Console.Write($"Value for [{i}, {j}]: ");
            //        jaggedArray[i][j] = int.Parse(Console.ReadLine());
            //    }
            //}
            //Console.WriteLine("\nValues in the jagged array:");
            //for (int i = 0; i < jaggedArray.Length; i++)
            //{
            //    Console.Write($"Row {i + 1}: ");
            //    foreach (int value in jaggedArray[i])
            //    {
            //        Console.Write(value + " ");
            //    }
            //    Console.WriteLine();
            //}
            ////Jagged arrays provide more flexibility and can save memory for scenarios with varying row sizes,
            ////while rectangular arrays are simpler and better suited for uniform grids.
            #endregion
            #region Q7
            //string? userInput = null;
            //Console.Write("Enter a value (or leave blank for null): ");
            //string input = Console.ReadLine();
            //if (!string.IsNullOrWhiteSpace(input))
            //{
            //    userInput = input;
            //}
            //Console.WriteLine($"You entered: {userInput!}");
            #endregion
            #region Q8
            //int valueType = 42;
            //object boxedValue = valueType;
            //Console.WriteLine($"Boxed value: {boxedValue}");
            //try
            //{
            //    int unboxedValue = (int)boxedValue;
            //    Console.WriteLine($"Unboxed value: {unboxedValue}");
            //    string invalidUnboxing = (string)boxedValue;
            //}
            //catch (InvalidCastException ex)
            //{
            //    Console.WriteLine($"Error: {ex.Message}");
            //}
            ////What is the performance impact of boxing and unboxing in C#?
            ////Boxing and unboxing negatively impact performance due to:
            ////Heap Allocation: Boxing allocates memory on the heap, which is slower than stack allocation.
            ////Garbage Collection Overhead: Boxed objects require garbage collection, adding extra overhead.
            ////CPU Overhead: Additional operations like copying and type checking during boxing / unboxing consume CPU resources.
            ////Loop Performance: Frequent boxing/ unboxing in loops can significantly degrade performance.
            #endregion
            #region Q9
            //SumAndMultiply(4, 5, out int sum, out int product);
            //Console.WriteLine($"Sum: {sum}, Product: {product}");


            ////Why must out parameters be initialized inside the method?
            ////Out parameters must be explicitly initialized inside the method because they do not retain any previous value when passed to the method.
            ////The compiler enforces this to ensure the caller receives a valid and defined result after the method executes.
            #endregion
            #region Q10
            //PrintMultipleTimes("Hello");
            //PrintMultipleTimes("Hi", count: 3);
            ////Why must optional parameters always appear at the end of a method's parameter list?
            ////Optional parameters must appear at the end of the parameter list to ensure proper method invocation.
            ////When a method is called, arguments are matched to parameters in order.
            ////If optional parameters were placed before required parameters, it could create ambiguity in matching arguments,
            ////leading to compiler errors.
            #endregion
            #region Q11
            //int[]? nullableArray = null;
            //Console.WriteLine($"Array Length: {nullableArray?.Length ?? 0}");
            //nullableArray = new int[] { 1, 2, 3, 4, 5 };
            //Console.WriteLine($"Array Length: {nullableArray?.Length}");

            ////How does the null propagation operator prevent NullReferenceException?
            ////The null propagation operator (?.) ensures safe access to members or properties of objects that may be null.
            ////If the object is null, the operator short-circuits and returns null instead of attempting to access the member,
            ////preventing a NullReferenceException.This eliminates the need for explicit null checks and makes code cleaner and safer.

            #endregion
            #region Q12
            //Console.Write("Enter a day of the week: ");
            //string day = Console.ReadLine();
            //int dayNumber = day switch
            //{
            //    "Monday" => 1,
            //    "Tuesday" => 2,
            //    "Wednesday" => 3,
            //    "Thursday" => 4,
            //    "Friday" => 5,
            //    "Saturday" => 6,
            //    "Sunday" => 7,
            //    _ => 0
            //};
            //if (dayNumber == 0)
            //{
            //    Console.WriteLine("Invalid day entered.");
            //}
            //else
            //{
            //    Console.WriteLine($"The number for {day} is {dayNumber}.");
            //}

            ////When is a switch expression preferred over a traditional if statement ?
            ////A switch expression is preferred over a traditional if statement when:
            ////Multiple Conditions: There are multiple mutually exclusive conditions to evaluate.
            ////Simpler Syntax: The switch expression is more concise and readable than nested or chained if-else statements.
            ////Better Maintenance: It is easier to add or modify cases in a switch expression compared to multiple if-else blocks.
            ////Pattern Matching: Switch expressions support advanced pattern matching, making them more powerful and expressive.
            #endregion
            #region Q13
            //int sum1 = SumArray(1, 2, 3, 4, 5);
            //Console.WriteLine($"Sum of individual values: {sum1}");

            //int[] numbers = { 10, 20, 30 };
            //int sum2 = SumArray(numbers);
            //Console.WriteLine($"Sum of array values: {sum2}");
            #endregion
            #endregion

            #region PART2
            #region Q1
            //Console.Write("Enter a positive integer: ");
            //int number = int.Parse(Console.ReadLine());

            //if (number <= 0)
            //{
            //    Console.WriteLine("Please enter a positive integer.");
            //}
            //else
            //{
            //    Console.WriteLine("Output:");
            //    for (int i = 1; i <= number; i++)
            //    {
            //        Console.Write(i);
            //        if (i < number) Console.Write(", "); // Add a comma except for the last number
            //    }
            //}
            #endregion
            #region Q2
            //Console.Write("Enter an integer: ");
            //int number = int.Parse(Console.ReadLine());

            //Console.WriteLine("Multiplication Table:");
            //for (int i = 1; i <= 12; i++)
            //{
            //    int result = number * i;
            //    Console.Write(result);
            //    if (i < 12) Console.Write(", ");
            //}
            #endregion
            #region Q3
            //Console.Write("Enter a number: ");
            //int number = int.Parse(Console.ReadLine());

            //Console.WriteLine("Even numbers between 1 and " + number + ":");
            //bool isFirst = true; // Flag to handle the comma placement

            //for (int i = 2; i <= number; i += 2) // Start from 2 and increment by 2
            //{
            //    if (!isFirst)
            //    {
            //        Console.Write(", "); // Add a comma before each number except the first one
            //    }
            //    Console.Write(i);
            //    isFirst = false; // After the first number, set the flag to false
            //}
            #endregion
            #region Q4
            //Console.Write("Enter the base number: ");
            //int baseNumber = int.Parse(Console.ReadLine());

            //Console.Write("Enter the exponent: ");
            //int exponent = int.Parse(Console.ReadLine());

            //int result = 1;
            //for (int i = 1; i <= exponent; i++)
            //{
            //    result *= baseNumber;
            //}
            //Console.WriteLine($"Result: {baseNumber}^{exponent} = {result}");
            #endregion
            #region Q5
            //Console.Write("Enter a string: ");
            //string input = Console.ReadLine();

            //char[] charArray = input.ToCharArray();
            //Array.Reverse(charArray);
            //string reversedString = new string(charArray);

            //Console.WriteLine($"Reversed string: {reversedString}");
            #endregion
            #region Q6
            //Console.Write("Enter an integer: ");
            //int number = int.Parse(Console.ReadLine());
            //int reversedNumber = 0;
            //while (number != 0)
            //{
            //    int digit = number % 10;
            //    reversedNumber = reversedNumber * 10 + digit;
            //    number /= 10;
            //}
            //Console.WriteLine($"Reversed integer: {reversedNumber}");
            #endregion
            #region Q7
            //Console.Write("Enter the size of the array: ");
            //int N = int.Parse(Console.ReadLine());
            //int[] array = new int[N];
            //Console.WriteLine("Enter the elements of the array:");
            //for (int i = 0; i < N; i++)
            //{
            //    array[i] = int.Parse(Console.ReadLine());
            //}
            //int longestDistance = 0;
            //for (int i = 0; i < array.Length; i++)
            //{
            //    for (int j = i + 1; j < array.Length; j++)
            //    {
            //        if (array[i] == array[j])
            //        {
            //            int distance = j - i - 1;
            //            longestDistance = Math.Max(longestDistance, distance);
            //        }
            //    }
            //}
            Console.WriteLine($"Longest distance between matching elements: {longestDistance}");
            #endregion
            #region Q8
            Console.Write("Enter a sentence: ");
            string sentence = Console.ReadLine();
            string[] words = sentence.Split(' ');
            string reversedSentence = string.Join(" ", words.Reverse());
            Console.WriteLine(reversedSentence);
            #endregion
            #endregion

        }
        //Q2
        public static void TestDefensiveCode()
        {
            int X, Y;
            do
            {
                Console.Write("Enter X: ");
            }
            while (!int.TryParse(Console.ReadLine(), out X));

            do
            {
                Console.Write("Enter Y: ");
            }
            while (!int.TryParse(Console.ReadLine(), out Y) || Y <= 1);

            Console.WriteLine(X / Y);
        }
        //Q9
        static void SumAndMultiply(int a, int b, out int sum, out int product)
        {
            sum = a + b;
            product = a * b;
        }

        //Q10
        static void PrintMultipleTimes(string message, int count = 5)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine(message);
            }
        }
        //Q13
        static int SumArray(params int[] numbers)
        {
            int sum = 0;
            foreach (int number in numbers)
            {
                sum += number;
            }
            return sum;
        }
    }
}
